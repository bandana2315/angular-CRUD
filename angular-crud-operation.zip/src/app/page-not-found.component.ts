import { Component } from '@angular/core';

@Component({
  selector: 'not-found',
  template: '<p>Not Found</p>'
})
export class PageNotFoundComponent  {
}
