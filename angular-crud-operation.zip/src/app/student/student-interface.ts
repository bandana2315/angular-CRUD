export interface Student {
  name: string;
  id: string;
  gender: string;
  address: string;
}